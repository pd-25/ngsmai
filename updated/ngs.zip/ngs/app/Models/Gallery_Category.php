<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Gallery_Category extends Model
{
    protected $table = 'gallery_category';
}
