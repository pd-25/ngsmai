<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Expance extends Model
{
    protected $table = 'expance';
}
