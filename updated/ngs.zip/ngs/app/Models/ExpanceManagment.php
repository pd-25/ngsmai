<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ExpanceManagment extends Model
{
    protected $table = 'expance_managment';
}
