@extends('admin.layouts.app')

@section('panel')
<h1>hello sdsd</h1>


















@endsection
